CTEC YC Dataset Version 3

Purpose:
Create a realistic digital twin of a supply-chain enterprise.

Demo Story:
1. Ingest data from multiple enterprise systems.
2. Resolve duplicate identities.
3. Build canonical Enterprise Entities.
4. Create Assertions and Evidence.
5. Institutionalize Knowledge.
6. Ask explainable business questions.
7. Produce transparent reasoning.
8. Record decisions, outcomes and experiences.
